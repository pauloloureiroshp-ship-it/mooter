#!/usr/bin/env node
// Frugal model-emoji tag for each tool call.
// Primary source: the transcript JSONL — last assistant message's `model`
// field is the actual model executing this tool call.
// Fallback: decisions.log router recommendation for the session.
// Never blocks or mutates the tool call. Silent on any error.

const fs = require('fs');
const path = require('path');
const os = require('os');

function getModelEmoji(model) {
  if (!model) return '❓';
  const m = String(model).toLowerCase();
  if (m.includes('opus')) return '🔴';
  if (m.includes('sonnet')) return '🟡';
  if (m.includes('haiku')) return '⚡';
  if (m.includes('qwen') || m.includes('ollama') || m.includes('local')) return '🦙';
  if (m.includes('codex') || m.includes('openai') || m.includes('gpt')) return '🟩';
  if (m.includes('gemini') || m.includes('google')) return '💎';
  return '❓';
}

function readStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch (e) { return ''; }
}

function tailLines(filePath, maxBytes = 65536) {
  const stat = fs.statSync(filePath);
  const size = stat.size;
  const start = Math.max(0, size - maxBytes);
  const fd = fs.openSync(filePath, 'r');
  const len = size - start;
  const buf = Buffer.alloc(len);
  fs.readSync(fd, buf, 0, len, start);
  fs.closeSync(fd);
  return buf.toString('utf8').split('\n').filter(Boolean);
}

function getModelFromTranscript(transcriptPath) {
  if (!transcriptPath || !fs.existsSync(transcriptPath)) return null;
  try {
    const lines = tailLines(transcriptPath, 131072);
    for (let i = lines.length - 1; i >= 0; i--) {
      let obj;
      try { obj = JSON.parse(lines[i]); } catch (e) { continue; }
      const msg = obj && obj.message;
      if (msg && msg.role === 'assistant' && msg.model) return msg.model;
    }
  } catch (e) {}
  return null;
}

function findDecision(sessionId) {
  const logPath = path.join(os.homedir(), '.claude', 'tools', 'router', 'decisions.log');
  if (!fs.existsSync(logPath)) return null;
  const lines = tailLines(logPath);
  // search backwards for the most recent classified entry (matching session_id if present)
  for (let i = lines.length - 1; i >= 0; i--) {
    let obj;
    try { obj = JSON.parse(lines[i]); } catch (e) { continue; }
    if (obj.event !== 'classified') continue;
    if (sessionId && obj.session_id && obj.session_id !== sessionId) continue;
    return obj;
  }
  // best-effort fallback: last classified entry regardless of session
  for (let i = lines.length - 1; i >= 0; i--) {
    let obj;
    try { obj = JSON.parse(lines[i]); } catch (e) { continue; }
    if (obj.event === 'classified') return obj;
  }
  return null;
}

(function main() {
  let sessionId = null;
  let transcriptPath = null;
  try {
    const raw = readStdin();
    if (raw) {
      const payload = JSON.parse(raw);
      sessionId = payload.session_id || payload.sessionId || null;
      transcriptPath = payload.transcript_path || payload.transcriptPath || null;
    }
  } catch (e) { /* ignore */ }

  let model = null;
  try { model = getModelFromTranscript(transcriptPath); } catch (e) {}
  if (!model) {
    try {
      const decision = findDecision(sessionId);
      model = decision ? (decision.recommended_model || decision.model) : null;
    } catch (e) {}
  }
  const emoji = getModelEmoji(model);

  process.stdout.write(JSON.stringify({
    continue: true,
    suppressOutput: false,
    systemMessage: emoji
  }));
  process.exit(0);
})();
