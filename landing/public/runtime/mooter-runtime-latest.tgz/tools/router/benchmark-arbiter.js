#!/usr/bin/env node
// benchmark-arbiter.js — compare local Ollama models as classifier arbiter.
//
// For each model, runs N ambiguous prompts from decisions.log through Ollama
// asking it to classify tier (T0-T3). Measures accuracy (against classify.js
// ground truth for high-confidence cases), latency, and tokens/sec.
//
// Usage: node benchmark-arbiter.js [--models=qwen3:30b,gemma4:e4b] [--n=30]

const fs = require('fs');
const path = require('path');
const os = require('os');

const LOG = path.join(os.homedir(), '.claude/tools/router/decisions.log');
const DEFAULT_MODELS = ['qwen2.5:3b', 'gemma3:12b', 'qwen3:30b'];
const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, v] = a.replace(/^--/, '').split('=');
    return [k, v ?? true];
  })
);

const MODELS = args.models ? args.models.split(',') : DEFAULT_MODELS;
const N = parseInt(args.n || '30', 10);

const ARBITER_PROMPT = (userPrompt) => `You are a task classifier. Output ONLY one of: T0, T1, T2, T3.

T0 = trivial local (greeting, short factual, single-word)
T1 = simple transform (commit msg, docstring, regex, format change)
T2 = bug investigation, root cause, planning, multi-step reasoning
T3 = architecture, multi-file refactor, production-critical, security

Task: ${userPrompt}

Answer with ONLY the tier label (T0/T1/T2/T3). No explanation.`;

function loadAmbiguous() {
  const lines = fs.readFileSync(LOG, 'utf8').trim().split('\n');
  const seen = new Set();
  const out = [];
  for (const line of lines) {
    try {
      const d = JSON.parse(line);
      if (!d.prompt_preview || d.event !== 'classified') continue;
      const isAmbiguous =
        (d.task_category || '').startsWith('ambiguous_') ||
        (d.confidence >= 0.4 && d.confidence <= 0.55);
      if (!isAmbiguous) continue;
      if (seen.has(d.prompt_preview)) continue;
      seen.add(d.prompt_preview);
      out.push({ prompt: d.prompt_preview, tier: d.tier, conf: d.confidence });
    } catch {}
  }
  return out.slice(0, N);
}

async function askOllama(model, prompt) {
  const t0 = Date.now();
  const res = await fetch('http://127.0.0.1:11434/api/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      prompt: ARBITER_PROMPT(prompt),
      stream: false,
      options: { temperature: 0, num_predict: 8 },
    }),
  });
  const j = await res.json();
  const ms = Date.now() - t0;
  const raw = (j.response || '').trim().toUpperCase();
  const tier = (raw.match(/T[0-3]/) || [null])[0];
  return { tier, ms, raw };
}

async function benchmarkModel(model, corpus) {
  console.log(`\n=== ${model} ===`);
  let total = 0;
  let matches = 0;
  let totalMs = 0;
  let errors = 0;
  for (const { prompt, tier: groundTruth } of corpus) {
    try {
      const { tier, ms } = await askOllama(model, prompt);
      total++;
      totalMs += ms;
      const ok = tier === groundTruth;
      if (ok) matches++;
      process.stdout.write(ok ? '.' : 'x');
    } catch (e) {
      errors++;
      process.stdout.write('E');
    }
  }
  console.log('');
  const avgMs = total ? Math.round(totalMs / total) : 0;
  const accuracy = total ? ((matches / total) * 100).toFixed(1) : '0';
  return { model, total, matches, accuracy, avgMs, errors };
}

async function main() {
  const corpus = loadAmbiguous();
  console.log(`Corpus: ${corpus.length} ambiguous prompts`);
  console.log(`Models: ${MODELS.join(', ')}`);
  const results = [];
  for (const m of MODELS) {
    results.push(await benchmarkModel(m, corpus));
  }
  console.log('\n\n╔══════════════════════════════════════════════════════════╗');
  console.log('║ RESULTS                                                  ║');
  console.log('╚══════════════════════════════════════════════════════════╝');
  console.log('model              accuracy   avg_ms   errors');
  console.log('─────────────────────────────────────────────');
  for (const r of results) {
    console.log(
      `${r.model.padEnd(18)} ${(r.accuracy + '%').padStart(7)}  ${(r.avgMs + 'ms').padStart(7)}  ${r.errors}`
    );
  }
  const out = path.join(
    os.homedir(),
    '.claude/tools/router/benchmark-results',
    `arbiter-${Date.now()}.json`
  );
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, JSON.stringify({ corpus_size: corpus.length, results }, null, 2));
  console.log(`\nSaved: ${out}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
