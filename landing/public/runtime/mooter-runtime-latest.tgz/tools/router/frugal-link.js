#!/usr/bin/env node

/**
 * frugal-link.js — Links local frugal install to authenticated Supabase account.
 * Usage: node frugal-link.js --token=<JWT>
 *
 * Called from the onboarding web page after the user completes setup.
 * Saves user_id and Supabase credentials to .frugal-auth.json.
 */

const fs = require('fs');
const path = require('path');

const SUPABASE_URL = 'https://eymtobwinevywmmlmxqa.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || '';

async function main() {
  const tokenArg = process.argv.find(a => a.startsWith('--token='));
  if (!tokenArg) {
    console.error('Usage: node frugal-link.js --token=<JWT>');
    process.exit(1);
  }

  const token = tokenArg.split('=')[1];

  // Validate token by fetching user
  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: {
        Authorization: `Bearer ${token}`,
        apikey: SUPABASE_ANON_KEY,
      },
    });

    if (!res.ok) {
      console.error('Invalid or expired token. Please try again from the onboarding page.');
      process.exit(1);
    }

    const user = await res.json();

    const authData = {
      user_id: user.id,
      supabase_url: SUPABASE_URL,
      supabase_anon_key: SUPABASE_ANON_KEY,
      linked_at: new Date().toISOString(),
    };

    const authPath = path.join(__dirname, '.frugal-auth.json');
    fs.writeFileSync(authPath, JSON.stringify(authData, null, 2));

    console.log(`✓ Linked to frugal as ${user.email}`);
    console.log(`  User ID: ${user.id}`);
    console.log(`  Auth saved to: ${authPath}`);
    console.log('');
    console.log('Your usage sessions will now sync to your dashboard.');
  } catch (err) {
    console.error('Failed to link:', err.message);
    process.exit(1);
  }
}

main();
