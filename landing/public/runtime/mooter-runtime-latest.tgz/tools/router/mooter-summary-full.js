#!/usr/bin/env node
'use strict';
/**
 * mooter-summary-full.js — Intelligence Dashboard v2
 *
 * Unified view that joins:
 *   - decisions.log          (real Claude Code usage + tester-synthetic prompts)
 *   - mooter-tester-stats    (algorithm-improvement lab: accuracy, model perf, optimiser)
 *   - mooter-quality-matrix  (A/B wins per model × category)
 *   - mooter-tester-backlog  (misroutings waiting to be fixed)
 *   - outcomes.jsonl         (positive/negative outcome signals)
 *   - metrics-snapshot.json  (token counters, if populated)
 *
 * Prints REAL USAGE separately from TESTER LAB so savings aren't inflated
 * by synthetic benchmark prompts.
 */

const fs   = require('fs');
const os   = require('os');
const path = require('path');

const HOME          = os.homedir();
const CLAUDE_ROUTER = path.join(HOME, '.claude', 'tools', 'router');
const FRUGAL_ROUTER = path.join(HOME, 'frugal', 'tools', 'router');

// ── helpers ────────────────────────────────────────────────────────────
const safeRead     = (p) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } };
const safeReadText = (p) => { try { return fs.readFileSync(p, 'utf8'); } catch { return ''; } };
const fmtUsd       = (n) => '$' + (n || 0).toFixed(2);
const fmtNum       = (n) => (n || 0).toLocaleString();
const pct          = (n, tot) => tot > 0 ? ((n / tot) * 100).toFixed(1) + '%' : 'n/a';
function bar(p, w) { w = w || 10; const f = Math.round((p/100)*w); return '█'.repeat(f) + '░'.repeat(w-f); }
function fmtTime(ts) { if (!ts) return 'n/a'; const d = new Date(ts); return d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0'); }
function fmtDate(ts) { if (!ts) return 'n/a'; const d = new Date(ts); return d.getFullYear() + '-' + (d.getMonth()+1).toString().padStart(2,'0') + '-' + d.getDate().toString().padStart(2,'0'); }
function fmtDuration(ms) { if (!ms || ms < 0) return 'n/a'; const m = Math.floor(ms/60000); const h = Math.floor(m/60); const r = m%60; return h > 0 ? h+'h '+r+'min' : r+'min'; }
function daysSince(ts) { if (!ts) return 0; return Math.floor((Date.now() - ts) / 86400000); }
function pickFirst(...cands) { for (const c of cands) { const v = safeRead(c); if (v) return v; } return null; }

// ── load data sources ──────────────────────────────────────────────────
const hw         = safeRead(path.join(CLAUDE_ROUTER, 'hw-capability.json')) || {};
const profile    = safeRead(path.join(CLAUDE_ROUTER, 'user-profile.json')) || {};
const verJson    = safeRead(path.join(CLAUDE_ROUTER, 'version.json')) || {};
const modeFile   = safeRead(path.join(CLAUDE_ROUTER, '.mooter-mode.json')) || {};
const snapshot   = safeRead(path.join(CLAUDE_ROUTER, 'metrics-snapshot.json')) || {};
const creds      = safeRead(path.join(HOME, '.claude', '.credentials.json')) || {};
const subProfile = safeRead(path.join(CLAUDE_ROUTER, 'subscription-profile.json')) || {};

// Tester data — check frugal first (canonical), claude as fallback
const testerStats    = pickFirst(path.join(FRUGAL_ROUTER, 'mooter-tester-stats.json'),   path.join(CLAUDE_ROUTER, 'mooter-tester-stats.json'));
const testerBacklog  = pickFirst(path.join(FRUGAL_ROUTER, 'mooter-tester-backlog.json'), path.join(CLAUDE_ROUTER, 'mooter-tester-backlog.json'));
const qualityMatrix  = pickFirst(path.join(FRUGAL_ROUTER, 'mooter-quality-matrix.json'), path.join(CLAUDE_ROUTER, 'mooter-quality-matrix.json'));
const testerFocus    = pickFirst(path.join(FRUGAL_ROUTER, 'mooter-tester-focus.json'),   path.join(CLAUDE_ROUTER, 'mooter-tester-focus.json'));

// ── decisions log ──────────────────────────────────────────────────────
const logText = safeReadText(path.join(CLAUDE_ROUTER, 'decisions.log'));
const allDecisions = logText.trim().split('\n').filter(Boolean)
  .map(l => { try { return JSON.parse(l); } catch { return null; } })
  .filter(Boolean);

const isTester = (d) => d.source === 'mooter-tester' || d.user === 'mooter-tester';
const testerDecisions = allDecisions.filter(isTester);
const realDecisions   = allDecisions.filter(d => !isTester(d));

// ── cost model ─────────────────────────────────────────────────────────
const TIER_COST = { T0: 0.000, T1: 0.003, T2: 0.018, T3: 0.120 };
const OPUS_COST = 0.120;

function computeCosts(list) {
  const tierCount = {T0:0,T1:0,T2:0,T3:0};
  const tierCost  = {T0:0,T1:0,T2:0,T3:0};
  list.forEach(d => {
    const t = d.tier || 'T0';
    tierCount[t] = (tierCount[t]||0) + 1;
    tierCost[t]  = (tierCost[t] ||0) + (TIER_COST[t]||0);
  });
  const actual = Object.values(tierCost).reduce((a,b)=>a+b,0);
  const opus   = list.length * OPUS_COST;
  const saved  = Math.max(0, opus - actual);
  const savedPct = opus > 0 ? (saved / opus * 100) : 0;
  return { total: list.length, tierCount, tierCost, actual, opus, saved, savedPct };
}

// Session window (last 2h)
const now = Date.now();
const SESSION_WINDOW = 2 * 60 * 60 * 1000;
const sessionDecisions = realDecisions.filter(d => d.ts && new Date(d.ts).getTime() >= now - SESSION_WINDOW);
const session = computeCosts(sessionDecisions);

let sessionStart = null, sessionEnd = null;
if (sessionDecisions.length) {
  const times = sessionDecisions.map(d => new Date(d.ts).getTime()).filter(t => !isNaN(t)).sort((a,b)=>a-b);
  sessionStart = times[0];
  sessionEnd   = times[times.length-1];
}

// Monthly
const now_d = new Date();
const monthStart = new Date(now_d.getFullYear(), now_d.getMonth(), 1).getTime();
const realMonth   = computeCosts(realDecisions.filter(d => d.ts && new Date(d.ts).getTime() >= monthStart));
const testerMonth = computeCosts(testerDecisions.filter(d => d.ts && new Date(d.ts).getTime() >= monthStart));

// All-time
const realAll   = computeCosts(realDecisions);
const testerAll = computeCosts(testerDecisions);

let earliestTs = null;
if (realDecisions.length) {
  const times = realDecisions.map(d => new Date(d.ts).getTime()).filter(t => !isNaN(t)).sort((a,b)=>a-b);
  earliestTs = times[0];
}

// ── outcomes ───────────────────────────────────────────────────────────
const outcomes = safeReadText(path.join(CLAUDE_ROUTER, 'outcomes.jsonl'))
  .trim().split('\n').filter(Boolean)
  .map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);

const posOut = outcomes.filter(o => o.outcome_score >= 0.5).length;
const negOut = outcomes.filter(o => o.outcome_score !== undefined && o.outcome_score < 0.5).length;
const totOut = posOut + negOut;
const posPct = totOut > 0 ? ((posOut/totOut)*100).toFixed(1) + '%' : 'n/a';

// ── OAuth / provider / hw ─────────────────────────────────────────────
const oauth = creds.claudeAiOauth || {};
const planRaw = oauth.subscriptionType || (subProfile.profiles && subProfile.profiles.anthropic) || 'unknown';
const planLabel = planRaw === 'max' ? 'Claude Max' : planRaw === 'pro' ? 'Claude Pro' : planRaw === 'free' ? 'Free' : planRaw;
const rateLimit = oauth.rateLimitTier || '';
const isMax = planRaw === 'max';

const gpuName = hw.name || hw.gpu_name || 'n/a';
const vramGb  = hw.vram_mb ? (hw.vram_mb/1024).toFixed(0)+'GB' : 'n/a';
const hwTier  = (hw.hw_tier || 'n/a').toUpperCase();
const ollamaModels = (hw.available_ollama_models || []).map(m => m.name || m);

// ── tester activity status ────────────────────────────────────────────
let testerAlive = false, testerLastSeen = 'n/a', testerStaleMin = 0;
if (testerStats && testerStats.updated_at) {
  const updated = new Date(testerStats.updated_at).getTime();
  testerStaleMin = Math.round((now - updated) / 60000);
  testerAlive = testerStaleMin < 5;
  testerLastSeen = fmtDate(updated) + ' ' + fmtTime(updated);
}

// ── health alerts (computed) ──────────────────────────────────────────
const alerts = [];

if (testerStats) {
  const mp = testerStats.model_performance || {};
  Object.entries(mp).forEach(([model, p]) => {
    if (p.runs >= 10 && p.errors / p.runs > 0.5) {
      alerts.push(`Model **${model}**: ${p.errors}/${p.runs} runs failed (${((p.errors/p.runs)*100).toFixed(0)}% error rate)`);
    }
  });

  const ta = testerStats.tier_accuracy || {};
  Object.entries(ta).forEach(([tier, v]) => {
    if (tier === 'null') return;
    if (v.total >= 50 && (v.correct / v.total) < 0.7) {
      alerts.push(`Tier **${tier}** accuracy is ${((v.correct/v.total)*100).toFixed(0)}% (${v.correct}/${v.total}) — below 70% floor`);
    }
  });

  if (testerStats.optimizer_ab_tests >= 5 && testerStats.optimizer_effectiveness) {
    const oe = testerStats.optimizer_effectiveness;
    const wr = parseFloat((oe.optimizer_win_rate || '0%').replace('%', ''));
    if (wr < 20) {
      alerts.push(`Prompt optimizer win rate is ${oe.optimizer_win_rate} in ${oe.tests_run} tests — not learning`);
    }
  }

  if (!testerAlive && testerStaleMin > 60) {
    alerts.push(`Continuous tester offline — last heartbeat ${testerStaleMin}min ago`);
  }
}

if (!snapshot.total_tokens_in && !snapshot.total_tokens_out && !snapshot.total_tokens) {
  alerts.push(`Token telemetry pipeline broken — metrics-snapshot.json shows 0 tokens despite ${fmtNum(allDecisions.length)} decisions`);
}

const backlogPending = testerBacklog?.findings?.misroutings?.filter(m => m.status === 'pending').length || 0;
if (backlogPending > 30) {
  alerts.push(`Misrouting backlog at **${backlogPending} pending findings** — classifier not self-healing`);
}

// ── print ──────────────────────────────────────────────────────────────
const lines = [];
const push = (...s) => lines.push(...s);
const rule = () => push('━'.repeat(56));

push('', '🎯 MOOTER — Intelligence Dashboard v2', '━'.repeat(56));

// Health alerts FIRST if any
if (alerts.length) {
  push('', '⚠️  HEALTH ALERTS (' + alerts.length + ')');
  alerts.slice(0, 8).forEach((a, i) => push('  ' + (i+1) + '. ' + a));
  push('');
}

// ── Session (real usage, last 2h) ─────────────────────────────────────
push('📊 SESSÃO (últimas 2h — USO REAL)');
if (session.total === 0) {
  push('  (sem prompts reais nesta janela)');
} else {
  push('  Prompts: ' + session.total + '  |  ' + fmtTime(sessionStart) + ' → ' + fmtTime(sessionEnd) + '  (' + fmtDuration(sessionEnd - sessionStart) + ')');
  ['T0','T1','T2','T3'].forEach(t => {
    const c = session.tierCount[t] || 0;
    if (!c) return;
    const labels = { T0:'Ollama', T1:'Haiku', T2:'Sonnet', T3:'Opus' };
    const p = Math.round((c/session.total)*100);
    push('  ' + (t+' '+labels[t]).padEnd(12) + ' ' + bar(p) + ' ' + (p+'%').padStart(4) + '  ' + fmtUsd(session.tierCost[t]));
  });
  push('  Custo: ' + fmtUsd(session.actual) + '  |  Poupou: ' + fmtUsd(session.saved) + ' (' + session.savedPct.toFixed(1) + '%)');
}

// ── Real usage this month ─────────────────────────────────────────────
const monthNames = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
push('', '💰 USO REAL — ' + monthNames[now_d.getMonth()] + ' ' + now_d.getFullYear());
push('  Prompts reais: ' + fmtNum(realMonth.total));
push('  Custo com Mooter:  ' + fmtUsd(realMonth.actual));
push('  Custo sem Mooter:  ' + fmtUsd(realMonth.opus));
push('  Poupança do mês:   ' + fmtUsd(realMonth.saved) + ' (' + realMonth.savedPct.toFixed(1) + '%)');

// ── All-time real ─────────────────────────────────────────────────────
push('', '💎 ALL-TIME (uso real, exclui tester)');
push('  Desde: ' + fmtDate(earliestTs) + ' (' + daysSince(earliestTs) + ' dias)');
push('  Prompts reais: ' + fmtNum(realAll.total));
push('  Poupança total: ' + fmtUsd(realAll.saved) + ' (' + realAll.savedPct.toFixed(1) + '% vs Opus-only)');
push('  Média/prompt: ' + fmtUsd(realAll.total > 0 ? realAll.saved/realAll.total : 0));

// ── Continuous Tester Lab ─────────────────────────────────────────────
rule();
push('🧪 CONTINUOUS TESTER LAB (algoritmo self-improvement)');
if (!testerStats) {
  push('  (sem dados — tester nunca correu ou path errado)');
} else {
  push('  Estado: ' + (testerAlive ? '✅ LIVE' : '🔴 OFFLINE') + '  |  Último sinal: ' + testerLastSeen + (testerStaleMin ? '  (' + testerStaleMin + 'min atrás)' : ''));
  push('  Uptime acumulado: ' + (testerStats.uptime_human || 'n/a') + '  |  Ciclos: ' + fmtNum(testerStats.cycles));
  push('  Prompts gerados: ' + fmtNum(testerStats.prompts_generated) + '  |  Executados: ' + fmtNum(testerStats.prompts_executed));
  push('  Misroutings detectados: ' + testerStats.misroutings_found + '  |  Fixes aplicados: ' + testerStats.fixes_applied + '  |  Revertidos: ' + testerStats.fixes_reverted);
  push('  Cost real ($): ' + fmtUsd(testerStats.cost_usd || 0) + ' (100% local via Ollama)');
  push('  Prompts sintéticos no log: ' + fmtNum(testerAll.total) + ' (equivale a ~' + fmtUsd(testerAll.saved) + ' em custo evitado se fossem reais)');

  // Tier accuracy
  const ta = testerStats.tier_accuracy || {};
  const tiersOrdered = ['T0','T1','T2','T3'].filter(t => ta[t]);
  if (tiersOrdered.length) {
    push('', '  📊 Tier accuracy (classifier vs ground truth)');
    tiersOrdered.forEach(t => {
      const v = ta[t];
      const p = v.total > 0 ? ((v.correct/v.total)*100) : 0;
      const flag = p < 70 ? ' ⚠️' : p > 90 ? ' ✅' : '';
      push('    ' + t + '  ' + bar(p) + ' ' + (p.toFixed(0)+'%').padStart(4) + '  (' + v.correct + '/' + v.total + ')' + flag);
    });
  }

  // Model performance
  const mp = testerStats.model_performance || {};
  const mpEntries = Object.entries(mp).filter(([,v]) => v.runs > 0).sort((a,b) => b[1].runs - a[1].runs);
  if (mpEntries.length) {
    push('', '  🤖 Model performance (local Ollama)');
    push('    Model                Runs  Errors  ErrRate   AvgLat    AvgTok');
    mpEntries.forEach(([model, v]) => {
      const errRate = v.runs > 0 ? (v.errors/v.runs*100) : 0;
      const flag = errRate > 50 ? ' 🔴' : errRate > 20 ? ' 🟠' : '';
      push('    ' + model.padEnd(20) +
        String(v.runs).padStart(5) +
        String(v.errors).padStart(8) +
        (errRate.toFixed(0)+'%').padStart(8) +
        ((v.avg_latency_ms/1000).toFixed(1)+'s').padStart(9) +
        String(v.avg_tokens).padStart(8) + flag);
    });
  }

  // A/B quality matrix
  if (qualityMatrix && Object.keys(qualityMatrix).length) {
    push('', '  ⚔️  A/B quality wins (por model × category)');
    Object.entries(qualityMatrix).slice(0, 8).forEach(([k, v]) => {
      push('    ' + k.padEnd(44) + ' ' + v.wins + 'W/' + v.losses + 'L/' + v.ties + 'T  win_rate=' + v.win_rate);
    });
  }

  // Optimizer effectiveness
  const oe = testerStats.optimizer_effectiveness;
  if (oe && oe.tests_run > 0) {
    push('', '  🎯 Prompt-optimizer effectiveness');
    push('    Tests: ' + oe.tests_run + '  |  Optimizer wins: ' + oe.wins + '  Raw wins: ' + oe.losses + '  Ties: ' + oe.ties + '  |  Win rate: ' + oe.optimizer_win_rate);
  }

  // Backlog top 3
  const pending = testerBacklog?.findings?.misroutings?.filter(m => m.status === 'pending') || [];
  if (pending.length) {
    push('', '  📝 Misrouting backlog (' + pending.length + ' pending — top 3 mais recentes)');
    pending.slice(0, 3).forEach((m, i) => {
      const preview = (m.prompt_preview || '').slice(0, 60).replace(/\s+/g, ' ');
      push('    ' + (i+1) + '. [' + (m.expected || '?') + '→' + (m.classified || '?') + '] ' + preview + (m.prompt_preview && m.prompt_preview.length > 60 ? '…' : ''));
    });
  }
}

// ── Quality signals ───────────────────────────────────────────────────
rule();
push('📈 QUALITY SIGNALS');
push('  Outcomes: ' + posOut + ' positivos / ' + negOut + ' negativos' + (totOut > 0 ? '  (pos rate: ' + posPct + ')' : ''));
push('  Shadow A/B: ' + (outcomes.filter(o=>o.outcome_source==='shadow').length || 'n/a') + '  |  Explícito: ' + (outcomes.filter(o=>o.outcome_source==='explicit').length || 'n/a'));

// ── Env ───────────────────────────────────────────────────────────────
rule();
push('👤 ' + planLabel + (rateLimit ? ' (' + rateLimit + ')' : '') + (isMax ? '  —  flat rate, savings = deflection de Opus' : ''));
push('🖥️  ' + (process.platform === 'win32' ? 'Windows' : process.platform) + ' · ' + gpuName + ' · ' + vramGb + ' VRAM · tier ' + hwTier);
push('🦙 Ollama: ' + (ollamaModels.length ? ollamaModels.join(', ') : 'não detectado'));
push('🔑 Claude OAuth: ' + (oauth.accessToken ? '✅' : '❌') + '  Anthropic: ' + (process.env.ANTHROPIC_API_KEY ? '✅' : '❌') + '  Gemini: ' + ((process.env.GEMINI_API_KEY||process.env.GOOGLE_API_KEY) ? '✅' : '❌') + '  OpenAI: ' + (process.env.OPENAI_API_KEY ? '✅' : '❌'));
push('🔧 Router v' + (verJson.version || 'n/a') + '  |  Modo: ' + (modeFile.mode || 'auto'));

push('');
console.log(lines.join('\n'));
