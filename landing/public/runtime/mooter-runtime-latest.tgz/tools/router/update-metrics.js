#!/usr/bin/env node
'use strict';
/**
 * update-metrics.js — writes `metrics-snapshot.json` from decisions.log.
 *
 * Called by backtest.js after each backtest run (see backtest.js:749–756).
 * Also invocable directly: `node update-metrics.js`.
 *
 * Produces the schema mooter-summary-full.js expects:
 *   { generated_at, corpus_size, total_tokens_in, total_tokens_out, total_tokens,
 *     by_tier, by_tier_pct, cost:{real,naive,saved}, avg_confidence, date_range }
 */
const fs   = require('fs');
const os   = require('os');
const path = require('path');

const ROUTER_DIR = path.join(os.homedir(), '.claude', 'tools', 'router');
const LOG_PATH   = path.join(ROUTER_DIR, 'decisions.log');
const SNAP_PATH  = path.join(ROUTER_DIR, 'metrics-snapshot.json');

const { computeMetrics } = require('./savings-tracker');

let raw = '';
try { raw = fs.readFileSync(LOG_PATH, 'utf8'); }
catch (e) {
  console.error(`update-metrics: cannot read ${LOG_PATH}: ${e.message}`);
  process.exit(0);
}

const lines = raw.split('\n').filter(Boolean);
const m = computeMetrics(lines);

// Confidence avg (bounded to classified events with numeric confidence)
let confSum = 0, confN = 0;
let firstTs = null, lastTs = null;
for (const line of lines) {
  let e; try { e = JSON.parse(line); } catch { continue; }
  if (!e || e.event !== 'classified') continue;
  if (typeof e.confidence === 'number') { confSum += e.confidence; confN += 1; }
  if (e.ts) {
    const t = new Date(e.ts).getTime();
    if (!isNaN(t)) {
      if (firstTs === null || t < firstTs) firstTs = t;
      if (lastTs === null || t > lastTs)   lastTs = t;
    }
  }
}

const snap = {
  generated_at: new Date().toISOString(),
  corpus_size: m.prompts,
  total_tokens_in:  m.total_input_tokens,
  total_tokens_out: m.total_output_tokens,
  total_tokens:     m.total_tokens,
  by_tier: m.by_tier,
  by_tier_pct: m.pct_by_tier || null,
  cost: {
    real:  m.real_cost_estimated,
    naive: m.naive_cost,
    saved: m.saved,
    saved_pct: m.saved_pct,
  },
  avg_confidence: confN > 0 ? confSum / confN : null,
  date_range: firstTs && lastTs ? {
    from: new Date(firstTs).toISOString(),
    to:   new Date(lastTs).toISOString(),
    days: Math.max(1, Math.round((lastTs - firstTs) / 86400000)),
  } : null,
  option_a_hits: m.option_a_hits,
  system_prompts_filtered: m.system_prompts_filtered,
};

fs.writeFileSync(SNAP_PATH, JSON.stringify(snap, null, 2));
console.log(`update-metrics: wrote ${SNAP_PATH} (${m.prompts} prompts, ${m.total_tokens} tokens)`);
