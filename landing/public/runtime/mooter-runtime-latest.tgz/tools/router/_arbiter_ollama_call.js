#!/usr/bin/env node
// Helper spawned by arbiter.js callOllamaSync().
// Separate file because Windows spawnSync silently corrupts argv when
// passing `-e <scriptText>` together with a 2KB system prompt.
// Usage: node _arbiter_ollama_call.js <model> <system_prompt> <user_prompt>
const http = require('http');

const [model, systemPrompt, userPrompt] = process.argv.slice(2);
if (!model || systemPrompt == null || userPrompt == null) {
  process.stderr.write('usage: _arbiter_ollama_call.js <model> <system> <prompt>\n');
  process.exit(64);
}

const body = JSON.stringify({
  model,
  prompt: userPrompt,
  system: systemPrompt,
  stream: false,
  think: false,
  options: { temperature: 0.1, num_predict: 1024 },
});

const host = process.env.OLLAMA_HOST || 'http://localhost:11434';
const u = new URL(host);

const req = http.request(
  {
    hostname: u.hostname,
    port: u.port || 11434,
    path: '/api/generate',
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'content-length': Buffer.byteLength(body),
    },
  },
  (res) => {
    let data = '';
    res.on('data', (c) => { data += c; });
    res.on('end', () => {
      try {
        process.stdout.write(JSON.parse(data).response || '');
      } catch {
        process.exit(3);
      }
    });
  }
);
req.on('error', () => process.exit(1));
req.setTimeout(7500, () => { req.destroy(); process.exit(2); });
req.write(body);
req.end();
