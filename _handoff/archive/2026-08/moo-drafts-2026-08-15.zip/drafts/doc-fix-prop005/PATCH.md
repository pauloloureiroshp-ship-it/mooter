# moo-draft · prop-005 — STRATEGY.md ganha o sha256 do classify.js (1 linha)

> Descoberto pela GPU deste Mac mini (job `job-msug5cp2-9d05`, gpt-oss:20b, 45s, $0).
> Draft — não aplicar sem review. Destino: PR do CC ou commit do Paulo.

**Ficheiro:** `docs/strategy/STRATEGY.md`, seção "Estado real" (onde diz *"`classify.js` FROZEN e verificado em CI"*).

**De:**
```
`classify.js` FROZEN e verificado em CI.
```

**Para:**
```
`classify.js` FROZEN e verificado em CI (sha256 `427d8c0b516315c6a858b183892ec26dc0fed7b52f11000e1e6b81fd364bc48f` — o mesmo do CLAUDE.md; se divergirem, um dos dois mente e resolve-se no dia).
```

**Porquê:** CLAUDE.md especifica o hash; STRATEGY.md (single source of truth) não. A regra do próprio STRATEGY.md — "se uma linha aqui contradiz o código, resolve-se no mesmo dia" — pede o número, não a promessa.

**Teste de CI que fecha o loop (opcional, 3 linhas):** grep do sha em ambos os docs + `shasum` do ficheiro; 3 valores iguais ou o CI fica vermelho.
