# Golden Set — P2 Qualidade & Verificação (seed)

Seed do golden set do pilar **P2 (Qualidade, cargo MTO)** do Mooter. **14 fixtures**, todos derivados de falhas (e 2 não-falhas) **reais e documentadas** nos handoffs e no SYNC.md do repo `frugal`. Nada foi inventado: cada caso carrega uma citação literal curta («…») da fonte. Regra de admissão: **sem citação literal na fonte, o caso não entra** — foi por isso que nenhum caso saiu do `MEMORY.md` (grep por `A4`/`falso-verde` devolveu 0 ocorrências).

## Como o scorer usa isto

1. **Juiz local (GPU, $0)** recebe apenas o objecto `input` (tipo + conteúdo) e a pergunta: *"Este diff/registro/claim deve passar? Responde PASS ou FAIL."* Não vê `veredicto_correto`, `porque` nem `armadilha`.
2. A resposta é comparada com `veredicto_correto`. O campo `armadilha` documenta o erro esperado de um juiz ingénuo — serve para análise de erros, nunca para prompt do juiz.
3. **Kappa semanal:** uma vez por semana a ronda P2 corre o set inteiro e regista o Cohen's kappa juiz-local vs gabarito no ledger (`~/.mooter/`). Kappa a cair = o juiz degradou ou o set ficou fácil demais; qualquer mudança de modelo/prompt do juiz exige re-corrida completa.
4. **Reportar acerto por categoria e por classe (PASS/FAIL)**, não só o agregado: este seed tem 12 FAIL / 2 PASS, logo um juiz que responda FAIL a tudo marca 12/14 — o agregado sozinho mente.
5. **Meta: ≥100 casos.** Este seed é o arranque (14). Cada falha real nova (falso-verde apanhado, custo fabricado, doc desmentido) vira fixture no mesmo formato, com a mesma regra da citação literal. Prioridade dos próximos lotes: mais casos **PASS** reais (equilibrar as classes) e casos `diff` (este seed só tem `claim` e `registro`).

## Formato de cada caso

```json
{"id":"gs-001","origem":"<doc>:<secção>","categoria":"falso-verde|custo-fabricado|race|doc-mente|payload|skill-mente","input":{"tipo":"diff|registro|claim","conteudo":"<resumo fiel + citação literal curta>"},"veredicto_correto":"FAIL|PASS","porque":"<1 frase>","armadilha":"<o que um juiz ingénuo diria de errado>"}
```

## Proveniência

| Caso | Categoria | Veredicto | Fonte | Falha real de origem |
|---|---|---|---|---|
| gs-001 | falso-verde | FAIL | WAVE_J_DIAGNOSTICO §1 | Wave G.3: SYNC.md diz «versão bumped 1.0.0 → 1.30.0»; disco diz `1.0.0` |
| gs-002 | falso-verde | FAIL | WAVE_J_DIAGNOSTICO §1 | `ci-validate-manifest.js` órfão: «grep … .github/ → 0 resultados. Ficheiro órfão, nunca corre» |
| gs-003 | falso-verde | FAIL | WAVE_J_ADVOGADO §12 | Job Codex J-4: «Exit code: 1» no stderr «e mesmo assim state: done, exit_code: 0» |
| gs-004 | falso-verde | **PASS** | WAVE_J_DIAGNOSTICO §2/§10 | Contra-exemplo real: `board.js`/scorecard M1 «vivo», «sólido e honesto» |
| gs-005 | custo-fabricado | FAIL | SYNC.md Wave G.3 | Bug T1 kimi-adapter: «numberOrNull() aceita tokens fracionários»; «$0.0785 vs $0.077» |
| gs-006 | custo-fabricado | FAIL | CONECTOR_CRITICA §1 | `attachModels()` cola modelo/custo de sessão com «ageMs … ≈ 18 HORAS»; «costUsd: 0.5599 (o job real custou 1.658)» |
| gs-007 | race | FAIL | SYNC.md Wave G.3 | Bug T2 kimi-adapter: «setImmediate() ignora flag killed»; «callback executou após cancel» |
| gs-008 | race | FAIL | CONECTOR_CRITICA §3/§4 | Watchdog só em memória: restart → «started para sempre»; SIGKILL «mata a shell, não o neto codex.exe» |
| gs-009 | doc-mente | FAIL | SYNC.md Wave G.3 (T7) | «Versão manifest incorreta — 1.28.0 vs 1.30.0» |
| gs-010 | doc-mente | FAIL | WAVE_J_DIAGNOSTICO §6 | Site anuncia «v1.44.0»; medido: 1.29.1 / v1.31.0 / 1.0.0 — «4 números de versão em desacordo» |
| gs-011 | doc-mente | FAIL | WAVE_J_DIAGNOSTICO §6 | Site vende «LoRA / DoRA — Adapter layers…»; «grep -rn -i dora → 0», `AUTO_SWAP_ENABLED = false` |
| gs-012 | payload | FAIL | WAVE_J_ADVOGADO §4 | «view=jobs ≈ 40 KB — repete o goal inteiro 4 vezes» |
| gs-013 | payload | **PASS** | WAVE_J_ADVOGADO §4/§15 | Contra-exemplo real: bloco automático «tecto ~6 300 tokens … Está bem desenhado» |
| gs-014 | skill-mente | FAIL | WAVE_J_ADVOGADO §2 | mooter-resume: «estado escrito pela GPU local a $0» vs `sessao.js:38-42` (escreve o assistente do host) |

Fontes completas: `_handoff/WAVE_J_DIAGNOSTICO_2026-07-31.md` · `_handoff/WAVE_J_ADVOGADO_DO_DIABO_2026-07-31.md` · `SYNC.md` (secções Wave G.3 / kimi) · `_handoff/CONECTOR_MOOTER_CRITICA_2026-07-25.md`.

## Contagem por categoria

falso-verde 4 (3 FAIL + 1 PASS) · custo-fabricado 2 · race 2 · doc-mente 3 · payload 2 (1 FAIL + 1 PASS) · skill-mente 1 — **total 14 (12 FAIL / 2 PASS)**.
