# Sonda Apple Silicon — moo-draft (prop-002)

> **moo-draft — NÃO aplicar sem review.** Isto é uma proposta; nenhum ficheiro
> do conector foi alterado. Requer aprovação do MEO antes de merge.

## Onde encaixa

A sonda de GPU do painel do Mooter é hoje nvidia-smi-only: no macOS devolve
`"gpu": {"available": false, "reason": "nvidia-smi não encontrado"}`. Este
draft substitui esse ramo quando `process.platform === 'darwin'`:

```js
if (process.platform === 'darwin') {
  const { sondaAppleSilicon } = await import('./sonda.mjs');
  gpu = await sondaAppleSilicon();
} else {
  // ramo nvidia-smi existente, inalterado
}
```

Node puro, zero dependências, zero sudo — só comandos sem privilégio:
`sysctl`, `ioreg`, `vm_stat`, `pgrep`, e leitura de
`~/.ollama/models/manifests`. `powermetrics` exige root, portanto
`utilizacao_gpu` devolve sempre `nd_porque` explicando isso (e % de GPU é
métrica banida do produto de qualquer forma). Todos os campos seguem o
contrato n/d-com-porquê: `{valor, fonte, medido_em}` ou `{valor: null, nd_porque}`.

## Teste manual (3 linhas)

```sh
node sonda.mjs                                   # imprime o JSON completo
node sonda.mjs | node -e 'JSON.parse(require("fs").readFileSync(0)); console.log("JSON válido")'
node -e 'import("./sonda.mjs").then(m => m.sondaAppleSilicon()).then(r => console.log(r.chip, r.ollama_vivo))'
```
