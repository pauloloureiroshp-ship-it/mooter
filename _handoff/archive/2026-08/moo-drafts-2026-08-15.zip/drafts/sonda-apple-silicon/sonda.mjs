// moo-draft — NÃO aplicar sem review (proposta prop-002)
// Sonda de GPU para Apple Silicon — conector Mooter.
// Node puro, zero deps, zero sudo. Substitui o ramo nvidia-smi quando
// process.platform === 'darwin'.
//
// Contrato n/d-com-porquê do Mooter:
//   cada campo é {valor, fonte, medido_em} ou {valor: null, nd_porque}.

import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readdir } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';

const execFileP = promisify(execFile);

function agora() {
  return new Date().toISOString();
}

function ok(valor, fonte) {
  return { valor, fonte, medido_em: agora() };
}

function nd(porque) {
  return { valor: null, nd_porque: porque };
}

// Corre um comando sem privilégio; falha → nd_porque com a mensagem literal.
async function cmd(bin, args) {
  const { stdout } = await execFileP(bin, args, { timeout: 5000 });
  return stdout.trim();
}

async function sondaChip() {
  try {
    const brand = await cmd('sysctl', ['-n', 'machdep.cpu.brand_string']);
    return ok(brand, 'sysctl -n machdep.cpu.brand_string');
  } catch (e) {
    return nd(String(e.message || e));
  }
}

async function sondaRamTotal() {
  try {
    const bytes = Number(await cmd('sysctl', ['-n', 'hw.memsize']));
    if (!Number.isFinite(bytes) || bytes <= 0) {
      return nd('hw.memsize devolveu valor não numérico');
    }
    return ok(Math.round((bytes / 1024 ** 3) * 10) / 10, 'sysctl -n hw.memsize');
  } catch (e) {
    return nd(String(e.message || e));
  }
}

// Pressão de memória via vm_stat: páginas livres + purgeáveis * page size.
async function sondaRamLivreEstimada() {
  try {
    const out = await cmd('vm_stat', []);
    const pageSizeMatch = out.match(/page size of (\d+) bytes/);
    const pageSize = pageSizeMatch ? Number(pageSizeMatch[1]) : 16384;
    const pega = (rotulo) => {
      const m = out.match(new RegExp(`${rotulo}:\\s+(\\d+)`));
      return m ? Number(m[1]) : 0;
    };
    const livres = pega('Pages free');
    const purgaveis = pega('Pages purgeable');
    const inativas = pega('Pages inactive');
    if (livres === 0 && purgaveis === 0 && inativas === 0) {
      return nd('vm_stat correu mas não devolveu contadores reconhecíveis');
    }
    const gb = ((livres + purgaveis + inativas) * pageSize) / 1024 ** 3;
    return ok(Math.round(gb * 10) / 10, 'vm_stat (free+purgeable+inactive; estimativa, não garantia)');
  } catch (e) {
    return nd(String(e.message || e));
  }
}

async function sondaGpuModelo() {
  try {
    const out = await cmd('ioreg', ['-rc', 'AGXAccelerator', '-d', '1']);
    // Procura "model" = <"Apple M2 Max"> ou IOClass/device name aproximado.
    const m =
      out.match(/"model"\s*=\s*<?"([^"]+)"/) ||
      out.match(/"IOClass"\s*=\s*"([^"]+)"/);
    if (m) return ok(m[1], 'ioreg -rc AGXAccelerator');
    return nd('ioreg correu mas não expôs o modelo da GPU (AGXAccelerator sem campo model legível)');
  } catch (e) {
    return nd(String(e.message || e));
  }
}

async function sondaOllamaVivo() {
  try {
    await cmd('pgrep', ['-x', 'ollama']);
    return ok(true, 'pgrep -x ollama');
  } catch (e) {
    // pgrep sai com código 1 quando não encontra — isso é um "false" válido.
    if (e && typeof e.code === 'number' && e.code === 1) {
      return ok(false, 'pgrep -x ollama (sem processo)');
    }
    return nd(String(e.message || e));
  }
}

async function sondaModelosInstalados() {
  try {
    const base = join(homedir(), '.ollama', 'models', 'manifests');
    // manifests/<registry>/<namespace>/<modelo>/<tag>
    const modelos = [];
    const registries = await readdir(base);
    for (const reg of registries) {
      let namespaces;
      try { namespaces = await readdir(join(base, reg)); } catch { continue; }
      for (const ns of namespaces) {
        let nomes;
        try { nomes = await readdir(join(base, reg, ns)); } catch { continue; }
        for (const nome of nomes) {
          let tags;
          try { tags = await readdir(join(base, reg, ns, nome)); } catch { continue; }
          for (const tag of tags) {
            modelos.push(ns === 'library' ? `${nome}:${tag}` : `${ns}/${nome}:${tag}`);
          }
        }
      }
    }
    return ok(modelos, 'ls ~/.ollama/models/manifests');
  } catch (e) {
    return nd(String(e.message || e));
  }
}

export async function sondaAppleSilicon() {
  if (process.platform !== 'darwin') {
    const porque = `plataforma é ${process.platform}, não darwin — esta sonda é só para Apple Silicon`;
    return {
      plataforma: nd(porque),
      chip: nd(porque),
      ram_total_gb: nd(porque),
      ram_livre_estimada: nd(porque),
      gpu_modelo: nd(porque),
      vram: nd(porque),
      utilizacao_gpu: nd(porque),
      ollama_vivo: nd(porque),
      modelos_instalados: nd(porque),
    };
  }

  const [chip, ramTotal, ramLivre, gpuModelo, ollamaVivo, modelos] =
    await Promise.all([
      sondaChip(),
      sondaRamTotal(),
      sondaRamLivreEstimada(),
      sondaGpuModelo(),
      sondaOllamaVivo(),
      sondaModelosInstalados(),
    ]);

  return {
    plataforma: ok('darwin (Apple Silicon)', 'process.platform'),
    chip,
    ram_total_gb: ramTotal,
    ram_livre_estimada: ramLivre,
    gpu_modelo: gpuModelo,
    // Memória unificada: a "VRAM" é a mesma RAM — apontar para ram_total_gb.
    vram: ramTotal.valor !== null && ramTotal.valor !== undefined && !('nd_porque' in ramTotal)
      ? ok({ unified: true, ver: 'ram_total_gb' }, 'arquitetura de memória unificada — VRAM = RAM partilhada')
      : nd('memória unificada: VRAM depende de ram_total_gb, que falhou'),
    utilizacao_gpu: nd(
      'powermetrics exige root; sem ele utilização de GPU não é medível — e % de GPU é métrica banida do produto de qualquer forma'
    ),
    ollama_vivo: ollamaVivo,
    modelos_instalados: modelos,
  };
}

// CLI: node sonda.mjs → imprime o JSON.
import { fileURLToPath } from 'node:url';
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  sondaAppleSilicon().then((r) => {
    process.stdout.write(JSON.stringify(r, null, 2) + '\n');
  });
}
