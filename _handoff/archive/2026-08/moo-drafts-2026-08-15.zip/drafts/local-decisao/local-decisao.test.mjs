// local-decisao.test.mjs — draft (flag moo-draft), prop-003
// Valida o contrato do campo local_decisao anexado ao evento "dispatched"
// do ledger (~/.mooter/ledger.jsonl). Ver PATCH_SPEC.md na mesma pasta.
//
// Correr: node --test local-decisao.test.mjs

import test from 'node:test';
import assert from 'node:assert/strict';

const CONFIANCAS = ['alta', 'media', 'baixa', 'n-d'];
const PORQUE_MAX = 140;

/**
 * Valida local_decisao de um evento dispatched.
 * Devolve { ok: true, nd: bool } ou { ok: false, erro: string }.
 * Campo ausente ou null = n/d (eventos antigos) — válido, nunca erro.
 */
export function validarLocalDecisao(evento) {
  if (evento == null || typeof evento !== 'object') {
    return { ok: false, erro: 'evento não é um objeto' };
  }
  const ld = evento.local_decisao;
  if (ld === undefined || ld === null) {
    return { ok: true, nd: true }; // compatibilidade: ausente/null = n/d
  }
  if (typeof ld !== 'object' || Array.isArray(ld)) {
    return { ok: false, erro: 'local_decisao deve ser objeto, null ou ausente' };
  }
  if (typeof ld.local !== 'boolean') {
    return { ok: false, erro: 'local_decisao.local deve ser bool' };
  }
  if (typeof ld.porque !== 'string' || ld.porque.length === 0) {
    return { ok: false, erro: 'local_decisao.porque deve ser string não-vazia' };
  }
  if (ld.porque.length > PORQUE_MAX) {
    return { ok: false, erro: `local_decisao.porque excede ${PORQUE_MAX} chars (${ld.porque.length})` };
  }
  if (!CONFIANCAS.includes(ld.confianca)) {
    return { ok: false, erro: `local_decisao.confianca deve ser um de ${CONFIANCAS.join('|')}` };
  }
  if (typeof ld.fonte !== 'string' || ld.fonte.length === 0) {
    return { ok: false, erro: 'local_decisao.fonte deve ser string não-vazia' };
  }
  const extras = Object.keys(ld).filter(k => !['local', 'porque', 'confianca', 'fonte'].includes(k));
  if (extras.length > 0) {
    return { ok: false, erro: `campos extra em local_decisao: ${extras.join(', ')}` };
  }
  return { ok: true, nd: false };
}

// Evento sintético no formato real do ledger (subset da amostra de 2026-08-01)
function eventoSintetico(localDecisao) {
  const e = {
    ts: '2026-08-15T10:00:00.000Z',
    kind: 'dispatched', // PATCH_SPEC §Facto medido: o ledger usa kind:"dispatched"
    job_id: 'job-teste-0001',
    wave: 'teste',
    agent: 'moo',
    tier: 'T0',
    step: 'S1',
    local: true,
  };
  if (localDecisao !== undefined) e.local_decisao = localDecisao;
  return e;
}

test('aceita local_decisao válida num evento sintético', () => {
  const ev = eventoSintetico({
    local: true,
    porque: 'modelo residente cobre a categoria; VRAM livre suficiente; sem escrita',
    confianca: 'alta',
    fonte: 'localfirst.js',
  });
  const r = validarLocalDecisao(ev);
  assert.equal(r.ok, true);
  assert.equal(r.nd, false);
});

test('aceita todas as confiancas do enum, incluindo n-d', () => {
  for (const c of CONFIANCAS) {
    const ev = eventoSintetico({ local: false, porque: 'quota preservada para T2', confianca: c, fonte: 'localfirst.js' });
    assert.equal(validarLocalDecisao(ev).ok, true, `confianca ${c} devia ser aceite`);
  }
});

test('rejeita porque com mais de 140 caracteres', () => {
  const ev = eventoSintetico({
    local: true,
    porque: 'x'.repeat(PORQUE_MAX + 1),
    confianca: 'media',
    fonte: 'localfirst.js',
  });
  const r = validarLocalDecisao(ev);
  assert.equal(r.ok, false);
  assert.match(r.erro, /140/);
});

test('aceita exatamente 140 caracteres (limite inclusivo)', () => {
  const ev = eventoSintetico({ local: true, porque: 'x'.repeat(PORQUE_MAX), confianca: 'baixa', fonte: 'localfirst.js' });
  assert.equal(validarLocalDecisao(ev).ok, true);
});

test('aceita ausencia do campo como n/d (evento antigo)', () => {
  const r = validarLocalDecisao(eventoSintetico(undefined));
  assert.equal(r.ok, true);
  assert.equal(r.nd, true);
});

test('aceita local_decisao null como n/d (formato atual do ledger)', () => {
  const r = validarLocalDecisao(eventoSintetico(null));
  assert.equal(r.ok, true);
  assert.equal(r.nd, true);
});

test('rejeita confianca fora do enum', () => {
  const ev = eventoSintetico({ local: true, porque: 'ok', confianca: 'altíssima', fonte: 'localfirst.js' });
  assert.equal(validarLocalDecisao(ev).ok, false);
});

test('rejeita porque vazia e campos em falta', () => {
  assert.equal(validarLocalDecisao(eventoSintetico({ local: true, porque: '', confianca: 'alta', fonte: 'localfirst.js' })).ok, false);
  assert.equal(validarLocalDecisao(eventoSintetico({ local: true, porque: 'ok', confianca: 'alta' })).ok, false);
  assert.equal(validarLocalDecisao(eventoSintetico({ porque: 'ok', confianca: 'alta', fonte: 'localfirst.js' })).ok, false);
});

test('rejeita campos extra (objeto plano fechado)', () => {
  const ev = eventoSintetico({ local: true, porque: 'ok', confianca: 'alta', fonte: 'localfirst.js', extra: 1 });
  assert.equal(validarLocalDecisao(ev).ok, false);
});
