# PATCH_SPEC — local_decisao no evento `dispatched` (prop-003) `moo-draft`

**Estado:** draft — flag `moo-draft`. Nada aqui foi aplicado a código; é a especificação para o CC aplicar.
**Origem:** PERGUNTAS_MEO P2 — "gravamos local_decisao {local, porque, confianca} no evento dispatched? É uma linha de código e transforma uma opinião numa estatística."
**Facto medido (2026-08-15):** o ledger `~/.mooter/ledger.jsonl` tem eventos `kind:"dispatched"` e `kind:"local_model_chosen"`, mas nenhum carrega uma `local_decisao` preenchida. Melhor ainda: a amostra real mostra que o evento `dispatched` **já emite a chave `"local_decisao":null`** — o slot existe, o localfirst decide em memória e a explicação morre ali. Este patch só preenche o slot.

## 1. Schema do campo

Anexado ao evento `dispatched` (o mesmo objeto que hoje sai como `null`):

```json
"local_decisao": {
  "local": true,
  "porque": "modelo residente cobre a categoria; VRAM livre suficiente; sem escrita",
  "confianca": "alta",
  "fonte": "localfirst.js"
}
```

| campo       | tipo    | regra |
|-------------|---------|-------|
| `local`     | bool    | obrigatório. Deve coincidir com o campo `local` do próprio evento (o top-level `"local":true` da amostra). Divergência é bug do emissor, não do leitor. |
| `porque`    | string  | obrigatória, não-vazia, **≤ 140 caracteres**. Frase humana, mesmo tom dos `*_porque` já existentes no ledger (`modelo_porque`, `cargo_porque`, `mapa_porque`). Truncar no emissor se preciso — nunca rejeitar o dispatch por causa disto. |
| `confianca` | string  | obrigatória, enum exato: `"alta" \| "media" \| "baixa" \| "n-d"`. `"n-d"` quando o decisor não sabe quantificar — nunca omitir o campo para dizer "não sei". |
| `fonte`     | string  | obrigatória. Nome do módulo que decidiu; hoje sempre `"localfirst.js"`. Se outro módulo ganhar a decisão no futuro, grava o nome dele. |

Sem campos extra. Objeto plano, uma linha, no espírito do resto do ledger.

## 2. Compatibilidade com eventos antigos

- Campo **ausente** ou **`null`** em eventos já gravados = **n/d**. Os dois casos são equivalentes para qualquer leitor (a amostra real tem `"local_decisao":null` explícito).
- **Nunca migrar retroativamente.** O ledger é append-only; reescrever linhas antigas para inventar razões que não foram gravadas destruiria exatamente a propriedade que o torna estatística e não opinião.
- Leitores (MOO, MIO, dashboards) devem tratar `local_decisao == null/ausente` como a categoria `n/d` nas contagens — não como erro, não como `confianca:"n-d"` sintética.

## 3. Ponto de inserção — CONTRATO, não linha

O CC confirma o sítio exato no código dele; esta spec só fixa o contrato:

- **Onde:** no único ponto onde o evento `dispatched` é construído e appendado ao `ledger.jsonl` — o mesmo ponto que hoje escreve `"local_decisao":null`.
- **O quê:** substituir o `null` pelo objeto que o decisor local-first **já tem em memória** no momento do dispatch (o localfirst já sabe `local`, já formulou a razão para escolher/recusar local, já tem uma noção de confiança). Não recalcular nada; não fazer segunda chamada ao decisor.
- **Restrições:**
  - Zero I/O novo, zero chamadas a modelo. É passar um objeto que já existe até à linha do append (~1 linha de plumbing + o objeto).
  - Se o decisor por alguma razão não correu (caminho de erro, dispatch forçado), gravar `null` como hoje — n/d honesto é melhor que razão inventada.
  - `local_model_chosen` **não muda**: `modelo_porque` explica *qual modelo*; `local_decisao.porque` explica *porquê local de todo*. São perguntas diferentes.
- **Nome exato do ficheiro/linha:** a confirmar pelo CC no código dele (o decisor é referido como `localfirst.js`; se o nome real diferir, `fonte` grava o nome real). Não inventar linha nesta spec.

## 4. O que isto destrava

- **MOO** passa a responder "o que impediu o resto?" — cada dispatch não-local traz a razão gravada (`porque`) em vez de uma reconstrução de memória. `grep '"local":false' \| jq .local_decisao.porque \| sort \| uniq -c` vira o relatório.
- **MIO** ganha estatística de acerto: cruzar `local_decisao.confianca` com o desfecho do job (`succeeded`/`failed`) diz se a confiança do localfirst está calibrada — "alta" que falha muito é sinal de routing a corrigir.
- P2 do PERGUNTAS_MEO fecha: a opinião ("acho que o local aguenta") vira série temporal auditável, ao custo prometido de ~uma linha.

## 5. Validação

Teste que acompanha esta spec: `local-decisao.test.mjs` (mesma pasta) — valida o schema num evento sintético, rejeita `porque` > 140 chars, aceita ausência/`null` como n/d.
